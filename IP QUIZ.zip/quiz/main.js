var answers = [
    {
        "question": "1",
        "answer": "1"
    },
    {
        "question": "2",
        "answer": "2"
    },
    {
        "question": "3",
        "answer": "2"
    },
    {
        "question": "4",
        "answer": "2"
    },
    {
        "question": "5",
        "answer": "2"
    },
    {
        "question": "6",
        "answer": "2"
    },
    {
        "question": "7",
        "answer": "2"
    },
    {
        "question": "8",
        "answer": "2"
    },
    {
        "question": "9",
        "answer": "2"
    },
    {
        "question": "10",
        "answer": "2"
    }
];

var verifiedAnswers = [];
var totalScore = 100;
var achievedScore = 0;

function verifyOption(question, answer) {
    var result;
    var index = answers.findIndex(item => item.question === question && item.answer === answer);
    if (index >= 0) {
        var searchIndex = verifiedAnswers.findIndex(item => item.question === question && item.answer === answer);
        if (searchIndex < 0) {
            achievedScore = achievedScore + 10;
            result = true;
        }
    } else {
        var negativeIndex = verifiedAnswers.findIndex(item => item.question === question);
        if (negativeIndex < 0) {
            achievedScore = achievedScore - 10;
            result = false;
        }
    }
    var data = {
        "question": question,
        "answer": answer,
        "result": result
    };
    var finalIndex = verifiedAnswers.findIndex(item => item.question === question);
    if (finalIndex > -1) {
        verifiedAnswers.splice(finalIndex, 1);
    }
    verifiedAnswers.push(data);
}

function displayResult() {
    var submitButton = document.getElementById('submit');
    submitButton.disabled = true;
    verifiedAnswers.forEach((item) => {
        var documentId = 'question_' + item.question;
        var idElement = document.getElementById(documentId);
        var fetchClassElement = (item.result) ? 'success-msg' : 'failure-msg';
        var myClassElement = idElement.getElementsByClassName(fetchClassElement);
        myClassElement[0]['style']['display'] = 'flex';
    });
    var alertMessage = 'You have achieved ' + achievedScore.toString() + '/' + totalScore.toString();
    // window.alert(alertMessage);
    setTimeout(() => {
        submitButton.disabled = false;
    }, 5000);
}